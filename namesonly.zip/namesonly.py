#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
For larger datasets > 10,000, use databse
"""
from future.builtins import next

import os
import csv
import re
import logging
import optparse
import pandas as pd

import dedupe
from unidecode import unidecode

# ## Logging
# logging, run python xyz.py -v
optp = optparse.OptionParser()
optp.add_option('-v', '--verbose', dest='verbose', action='count',
                help='Increase verbosity (specify multiple times for more)'
                )
(opts, args) = optp.parse_args()
log_level = logging.ERROR 
if opts.verbose:
    if opts.verbose == 1:
        log_level = logging.INFO
    elif opts.verbose >= 2:
        log_level = logging.DEBUG
logging.getLogger().setLevel(log_level)

# ## Setup

input_file = 'cipnameonly.csv'
output_file = 'cipnameonly_output.csv'
settings_file = 'cipnameonly_learned_settings'
training_file = 'cipnameonly_training.json'

def preProcess(column):
    """
    Do a little bit of data cleaning with the help of Unidecode and Regex.
    Things like casing, extra spaces, quotes and new lines can be ignored.
    """
    try : # python 2/3 string differences
        column = column.decode('utf8')
    except AttributeError:
        pass
    column = unidecode(column)
    column = re.sub('  +', ' ', column)
    column = re.sub('\n', ' ', column)
    column = column.strip().strip('"').strip("'").upper().strip()
    # If data is missing, indicate that by setting the value to `None`
    if not column:
        column = None
    return column

def readData(filename):
    """
    Read in our data from a CSV file and create a dictionary of records, 
    where the key is a unique record ID and each value is dict
    """

    data_d = {}
    with open(filename) as f: #,encoding='utf-8',errors='ignore'
        reader = csv.DictReader(f,delimiter='|')
        for row in reader:
            clean_row = [(k, preProcess(v)) for (k, v) in row.items()]
            row_id = int(row['AML_PTY_ID'])
            data_d[row_id] = dict(clean_row)

    return data_d

print('importing data ...')
data_d = readData(input_file)
print('Record count:' , f'{len(data_d):,}')

def blankcompare(field_1, field_2) :
	if field_1 is None or field_2 is None:
		return 0


# If a settings file already exists, just load that and skip training
if os.path.exists(settings_file):
    print('reading from', settings_file)
    with open(settings_file, 'rb') as f:
        deduper = dedupe.StaticDedupe(f)
else:
    # ## Training

    # Define the fields for compare
#RN,AML_PTY_ID,NAM,REG_NAM,FRST_NAM,LST_NAM,REG_FL_NAM,TYP_CDE,FORM_DOB,ALIAS_TYP_CDE,ALIAS_VAL_TXT,ADR_LN1_TXT,REG_ADR_LN1_TXT#,ADR_LN2_TXT,CTY_NAM,REG_CTY_NAM,ST_NAM,REG_ST_NAM,PSTL_CDE,REG_PSTL_CDE,CNTRY_PHYSICAL,CORF,ROLE,DOB_C,GOC_C,ADDP_C,ADD_C,COR#_C
    fields = [
        {'field' : 'TYP_CDE', 'type': 'Exact'},
        {'field' : 'REG_NAM', 'type': 'String' }, #  'JaroWinkler'
        {'field' : 'CORF', 'type': 'Exact', 'has missing' : True} #,
        #{'field' : 'CORF', 'type': 'Custom', 'comparator': blankcompare}
        ]

    # Create a new deduper object and pass data model to it.
    deduper = dedupe.Dedupe(fields)

    # If training data saved from a previous run, load it in.
    # __Note:__ if you want to train from scratch, delete the training_file
    if os.path.exists(training_file):
        print('reading training data set from ', training_file)
        with open(training_file, 'rb') as f:
            deduper.prepare_training(data_d, f)
    else:
        deduper.prepare_training(data_d)

    # ## Active learning
    # find the next pair of records
    # least certain about and ask to label them as duplicates
    # or not.
    # use 'y', 'n' and 'u' keys to flag duplicates
    # press 'f' when you are finished
    print('starting active training/learning...')

    dedupe.consoleLabel(deduper)

    # Using the training set, train and learn
    # blocking predicates
    deduper.train()

    # When finished, save training to file
    with open(training_file, 'w') as tf:
        deduper.writeTraining(tf)

    # Save weights and predicates to file.  If the settings file
    # exists, skip all the training and learning next time run
    # this file.
    with open(settings_file, 'wb') as sf:
        deduper.writeSettings(sf)
        
# Find the threshold that will maximize a weighted average of 
# precision and recall.  When we set the recall weight to 2, we are
# saying we care twice as much about recall as we do precision.
#
# If we had more data, we would not pass in all the blocked data into
# this function but a representative sample.

threshold = deduper.threshold(data_d, recall_weight=1)
print('recall/threshold:' , 1)

# ## Clustering

# `match` will return sets of record IDs that 
# believes are all referring to the same entity.

print('clustering...')
clustered_dupes = deduper.match(data_d, threshold)

print('# duplicate sets', f'{len(clustered_dupes):,}')

# ## Writing Results

# Write original data back out to a CSV with a new column called 
# 'Cluster ID' which indicates which records refer to each other.

cluster_membership = {}
cluster_id = 0
for (cluster_id, cluster) in enumerate(clustered_dupes):
    id_set, scores = cluster
    cluster_d = [data_d[c] for c in id_set]
    canonical_rep = dedupe.canonicalize(cluster_d)
    for record_id, score in zip(id_set, scores):
        cluster_membership[record_id] = {
            "cluster id" : cluster_id,
            "canonical representation" : canonical_rep,
            "confidence": score
        }

singleton_id = cluster_id + 1
dupes_cnt = len(cluster_membership)-len(clustered_dupes)
print('# duplicate cnt', f'{dupes_cnt:,}')

with open(output_file, 'w',newline='') as f_output, open(input_file) as f_input: #,encoding='utf-8',errors='ignore' ,encoding='utf-8',errors='ignore'
    writer = csv.writer(f_output)
    reader = csv.reader(f_input,delimiter='|')

    heading_row = next(reader)
    heading_row.insert(0, 'confidence_score')
    heading_row.insert(0, 'Cluster_ID')
    canonical_keys = canonical_rep.keys()
    for key in canonical_keys:
        heading_row.append('canonical_' + key)

    writer.writerow(heading_row)

    for row in reader:
        row_id = int(row[0])
        if row_id in cluster_membership:
            cluster_id = cluster_membership[row_id]["cluster id"]
            canonical_rep = cluster_membership[row_id]["canonical representation"]
            row.insert(0, round(cluster_membership[row_id]['confidence'],2))
            row.insert(0, cluster_id)
			#if cluster_id != int(canonical_rep[0]) :
			#	dupes_cnt += 1
            for key in canonical_keys:
                row.append(canonical_rep[key]) #.encode('utf8'))
        else:
            row.insert(0, None)
            row.insert(0, singleton_id)
            singleton_id += 1
            for key in canonical_keys:
                row.append(None)
        writer.writerow(row)
	
data=pd.read_csv(output_file) 
data.sort_values(["Cluster_ID", "confidence_score"], axis=0, 
                 ascending=[True,False], 
inplace=True)
data.to_csv(r'output2.csv',index = None)
